#!/usr/bin/env python3
"""Verify the packaged endpoint-count files against graceful_counts_n5_71.tsv.

Checks per packaged n:
  - file has exactly n^2 rows (full ordered grid, no header)
  - sum of all counts equals G(n) in the master table
  - endpoint parity (Proposition: G(n;a,b) > 0 implies
    b - a = m(m+1)/2 (mod 2), m = n-1) has no violations
  - zigzag cell G(n; 0, ceil(m/2)) equals 1
  - decomposition parity: S and T2 (Proposition 3 of the note) and S + T2
Run from the package root:  python3 checks/verify_package.py
"""
import csv
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load_counts():
    g = {}
    with open(os.path.join(ROOT, "data", "graceful_counts_n5_71.tsv")) as f:
        for r in csv.DictReader(f, delimiter="\t"):
            g[int(r["n"])] = int(r["G"])
    return g


def load_endpoints(n):
    d = {}
    path = os.path.join(ROOT, "data", "endpoints", f"endpoints_n{n}.csv")
    with open(path) as f:
        for row in csv.reader(f):
            nn, a, b, c = int(row[0]), int(row[1]), int(row[2]), int(row[3])
            assert nn == n
            d[(a, b)] = c
    return d


def main():
    g = load_counts()
    ep_dir = os.path.join(ROOT, "data", "endpoints")
    ns = sorted(
        int(fn[len("endpoints_n"):-len(".csv")])
        for fn in os.listdir(ep_dir)
        if fn.startswith("endpoints_n")
    )
    ok = True
    for n in ns:
        m = n - 1
        d = load_endpoints(n)
        rows_ok = len(d) == n * n
        total = sum(d.values())
        target = m * (m + 1) // 2 % 2
        viol = sum(1 for (a, b), c in d.items() if c > 0 and (b - a) % 2 != target)
        zig = d[(0, (m + 1) // 2)]
        s = sum(c for (a, b), c in d.items() if a < b and a + b < m)
        t = sum(c for (a, b), c in d.items() if a < b and a + b == m)
        t2 = t // 2
        status = (
            rows_ok and total == g[n] and viol == 0 and zig == 1
            and t % 2 == 0 and (s + t2) % 2 == 0
        )
        ok = ok and status
        print(
            f"n={n}: rows={len(d)} total==G:{total == g[n]} "
            f"parity_violations={viol} zigzag={zig} "
            f"S%2={s % 2} T2%2={t2 % 2} S+T2 even:{(s + t2) % 2 == 0} "
            f"{'OK' if status else 'FAIL'}"
        )
    print("ALL OK" if ok else "FAILURES PRESENT")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
